class RoutesConstants {
  static const String login = '/login';
  static const String home = '/home';
  static const String welcome = '/welcome'; 
}
